from flask import Flask, render_template, request
import requests

app = Flask(__name__)

@app.route('/')
def upload():
    return render_template('index.html')

@app.route('/export', methods=['GET', 'POST'])
def userupload():
    f_in = request.files['file']

    #API_OF_IMAGGA
    f_in.save(f_in.filename)
    imagga_key = 'acc_2c074011352fbe6'
    imagga_secret = 'c1284d853596df0067bff036015aff75'

    imagga_upload = requests.post('https://api.imagga.com/v2/uploads',
        auth=(imagga_key, imagga_secret),
        files={'image': open(f_in.filename, 'rb')})
    res_post = imagga_upload.json()['result']['upload_id']

    img_search = requests.get('https://api.imagga.com/v2/tags',
        auth=(imagga_key, imagga_secret),
        params={'image_upload_id': res_post})
    img = img_search.json()['result']['tags'][0]['tag']['en']

    # API_OF_GHIPY
    img_search = requests.get('http://api.giphy.com/v1/gifs/search',
        params={'q': img,'api_key': '3tSZT7SnHBKuv8lIrb0b6QdinfGPVkb6'})
    select = img_search.json()['data']

    list = []
    for i in range(0, 10):
        selects = select[i]['images']['fixed_height']['url']
        list.append(selects)

    return render_template('export.html', selects=tuple(list))

if __name__ == '__main__':
    app.run(debug=True)